Hierarchical Data Format (hdf) I/O
==================================

The module contains I/O routines for Hierarchical Data Format: https://en.m.wikipedia.org/wiki/Hierarchical_Data_Format meant to store large amounts of data. This module does not implement the specs from scratch, it's a wrapper on top of libhdf5, which should be pre-installed by the user.
